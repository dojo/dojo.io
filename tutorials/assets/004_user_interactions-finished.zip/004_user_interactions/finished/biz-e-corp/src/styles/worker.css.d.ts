export const worker: string;
export const workerFront: string;
export const workerBack: string;
export const image: string;
export const imageSmall: string;
export const generalInfo: string;
export const task: string;
export const label: string;
