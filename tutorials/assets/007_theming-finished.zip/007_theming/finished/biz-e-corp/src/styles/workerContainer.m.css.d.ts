export const rootFixed: string;
export const root: string;
