export const root: string;
export const rootFixed: string;
export const nameField: string;
export const nameLabel: string;
export const workerButton: string;
