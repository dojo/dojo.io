export const root: string;
export const input: string;
