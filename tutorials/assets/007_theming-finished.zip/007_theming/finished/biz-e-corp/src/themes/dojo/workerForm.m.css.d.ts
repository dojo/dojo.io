export const root: string;
export const nameLabel: string;
