export const workerForm: string;
export const nameField: string;
export const nameLabel: string;
export const workerButton: string;
export const inputWrapper: string;
export const error: string;
