export const image: string;
export const worker: string;
export const workerFront: string;
export const workerBack: string;
export const reverse: string;
