export const generalInfo: string;
export const imageSmall: string;
export const label: string;
export const task: string;
