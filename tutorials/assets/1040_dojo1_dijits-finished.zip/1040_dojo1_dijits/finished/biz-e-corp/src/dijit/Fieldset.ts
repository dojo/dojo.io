import DijitWrapper from '@dojo/interop/dijit/DijitWrapper';
import * as Fieldset from 'dijit/Fieldset';

export default DijitWrapper(Fieldset, 'fieldset');
