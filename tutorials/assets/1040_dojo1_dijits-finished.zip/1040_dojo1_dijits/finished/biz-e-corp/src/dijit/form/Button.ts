import DijitWrapper from '@dojo/interop/dijit/DijitWrapper';
import * as Button from 'dijit/form/Button';

export default DijitWrapper(Button, 'button');
