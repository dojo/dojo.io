import DijitWrapper from '@dojo/interop/dijit/DijitWrapper';
import * as TextBox from 'dijit/form/TextBox';

export default DijitWrapper(TextBox, 'input');
