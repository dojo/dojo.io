var dojoConfig = {
	async: true
};
