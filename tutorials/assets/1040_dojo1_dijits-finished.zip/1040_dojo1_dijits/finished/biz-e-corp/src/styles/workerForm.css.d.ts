export const workerForm: string;
export const workerButton: string;
