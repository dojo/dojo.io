export const root: string;
export const container: string;
export const title: string;
export const links: string;
export const link: string;
export const main: string;
