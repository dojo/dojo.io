export const worker: string;
export const image: string;
export const generalInfo: string;
export const label: string;
export const task: string;
